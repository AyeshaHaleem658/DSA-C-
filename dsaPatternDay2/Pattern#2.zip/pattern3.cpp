#include<iostream>
using namespace std;
void pattern2(int patternRowColumn){
    for(int i = 1 ; i <= patternRowColumn ; i++){
        for(int j = 1 ; j <= i ; j++){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
int main(){
    int number;
    cout<<"ENTER A NUMBER : ";
    cin>>number;
    pattern2(number);
    return 0;
}