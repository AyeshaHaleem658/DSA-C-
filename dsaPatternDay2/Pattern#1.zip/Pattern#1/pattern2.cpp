#include<iostream>
using namespace std;
void basicPattern1(int n){
for(int i=0;i<n;i++){
    for(int j=0;j<=i;j++){
        cout<<" *";
    }
    cout<<endl;
}
}
int main(){
    int n;
    cout<<"ENTER THE NUMBER : ";
    cin>>n;
    basicPattern1(n);
    return 0;
}